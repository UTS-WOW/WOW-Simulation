"""The curriculum: from shooting at a target that does not move up to random fleet battles.

Learning the full game from scratch is too hard, so training starts with single skills and moves
to the next stage once the fleet wins often enough - like a student moving up a year. Every stage
asks for a 70 % win rate before moving on.

    Stage              Battle                         Fleet        Opponent                     Commander  tau
    0 Gunnery          gunnery (open sea)             1 BB vs CA   passive target               -          -
                         passed: the target sunk within 150 s
    1 Capture          capture (one circle)           1 CA         passive, far away            -          -
                         passed: the circle captured
    2 Defend           defend (a neutral circle)      1 CA vs CA   Recruit                      -          -
    3 Duel             bb_duel (open sea)             1v1 BB       Recruit 60 % / self-play 40  -          -
    4 King of the Hill koth_3v3 (one circle)          3v3 mixed    Veteran 60 % / self-play 40  on         0.3
    5 Archipelago      archipelago_3v3 (3 circles)    3v3 mixed    Veteran 60 % / self-play 40  on         0.5
    6 Domination       random map, random weather     6v6          Elite 40 % / self-play 60    on         0.8
    7 Open             random mode, map, weather      4-8 a side   Elite 40 % / self-play 60    on         1.0
    8 Archipelago 9v9  archipelago_9v9 (5 circles)    9v9, every   Elite 40 % / self-play 60    on         1.0
                                                      class

  self-play (league.py): "mirror" - the current fleet flies BOTH sides and both sides' experience
  trains it; "champion" - the strongest version so far, replaced only when the fleet beats it in 55 %
  of 40 battles (so it always has its best self to beat); "past" - older copies, the ones it loses to
  most often first; "rival" - the OTHER method's fleet (MAPPO <-> PQN, cross-play: different
  training, different habits). Promotion only ever counts the battles against the rule AI.
                                                                   stop: 70 % of 120 evaluation battles vs Elite

  The ships of each stage (classes: DD destroyer, CA cruiser, BB battleship, SS submarine):
    0  1 BB vs a passive CA      1  1 CA (+ a passive DD far away)   2  1 CA vs 1 CA     3  1 BB vs 1 BB
    4-5  1 BB + 1 CA + 1 DD a side
    6  the game's balanced 6-ship fleet: 1 BB, 2 CA, 2 DD, 1 SS a side
    7  the game's balanced fleet for 4-8 ships (submarines from 6 ships up)
    8  2 BB, 3 CA, 2 DD, 2 SS a side - every class that fights

A stage is a dict:

    name               shown in the logs (and in the game's TRAINING STAGES screen, with
    battle, description  a one-line summary of the battle and of what the stage teaches)
    scenario           a battle file from Training/scenarios (or a list: one is picked per battle)
      or
    procedural         a newly generated battle every time, any value "random" or a list to pick from:
                         mode           0 Domination, 1 Skirmish, 2 Fleet Battle, 3 Capture and Control
                         preset         0 archipelago, 1 open sea, 2 strait
                         density        islands: 0 low, 1 medium, 2 high
                         weather        0 clear, 1 fog, 2 rain, 3 storm
                         ships          [fewest, most] ships per side
                         time_limit     seconds (0: the mode's own)
                         capture_radius [smallest, largest] in game units (10 m each)
                         world_reuse    battles fought on one generated map before a new one
    difficulty         the rule-based AI: 0 Recruit, 1 Veteran, 2 Elite
    opponent           who flies the enemy fleet:
                         "rule"     the game's rule-based AI at `difficulty`
                         "passive"  a target: Python orders it to stop and hold fire
                         "league"   a mix, given by `opponents` (OpenAI Five / AlphaGo Zero / AlphaStar):
                                      rule     the rule AI at `difficulty` - the anchor that keeps the
                                               fleet honest, and the only battles that count for promotion
                                      mirror   our own current fleet on BOTH sides, and both sides learn
                                               (OpenAI Five's self-play): twice the data per battle
                                      latest   a frozen copy of our own fleet, refreshed every few updates
                                      past     an older copy from the league's pool, picked by
                                               prioritised fictitious self-play (the ones we lose to most)
                                      champion the strongest version so far (replaced when beaten in
                                               55 % of 40 battles - AlphaGo Zero's gating)
                                      rival    the other method's fleet: MAPPO's for the PQN run
                                               and the other way round (cross-play, model.set_rival)
                                    a champion / rival that does not exist yet plays a mirror battle
    opponents          for "league": shares, e.g. {"rule": 0.4, "mirror": 0.25, "champion": 0.1, ...}
    commander          True: the fleet commander gives orders in this stage (False: every ship is free)
    team_spirit        tau in rewards.py: how much each ship's own reward is shared with the fleet
    rehearsal          share of battles replayed from earlier stages, so old skills are not forgotten
                       (they are logged under their own stage and never count for promotion)
    pass_if            what counts as passing a battle: "won" (default), "sunk" (every enemy ship sunk) or
                       "captured" (a circle captured); within: ... in at most this many seconds of battle
                       (the battle ends at that time if the goal is not met by then). On a stage with
                       its own goal the win / loss reward follows the goal, not the game's result
    promote_win_rate   move on once the share of passed battles over the last `window` qualifying
    window               battles (against the stage's own opponent: rule AI or passive target) reaches this
    max_timesteps      move on anyway after this many timesteps on the stage, NOT passed, so a method that
                       cannot reach the bar does not train on it for ever (compare_stages shows the stage
                       as not passed); on the final stage, training ends there. Every default stage has
                       one, rising stage by stage and adding up to 3,000,000 timesteps for the whole
                       curriculum (80k / 100k / 150k / 250k / 300k / 350k / 500k / 570k / 700k) - one
                       notebook session each
    stop_win_rate      final stage only: stop training once the win rate over the last
    stop_window          `stop_window` evaluation battles reaches this. On a generated (procedural)
                         stage they are held-out battles, on maps whose seeds training never uses.
    eval_battles       held-out battles played each time the stopping rule is checked
    eval_every         timesteps between those checks
    reward_weights     optional overrides of rewards.py's weights for this stage only, e.g.
                         {"approach_circle": 0.0} - in the duel the circle lies between the two
                         battleships, so racing to it means sailing bow-on into the enemy's guns

Add as many stages as you like. The last stage has no promotion, so training stays on it until its
stopping rule is met or total_timesteps runs out - drop stop_win_rate to keep it going for good.

One network - one method, one checkpoint - plays every stage: the observation always has room for 9
ships a side and 5 circles (env.py, MAX_SHIPS / MAX_ZONES), and smaller battles fill the empty slots
with zeros and a mask. Promotion just changes the battles; training carries on with the same model.
"""

from __future__ import annotations

import csv
import json
import os

import numpy as np

from .callbacks import BaseCallback

NO_CIRCLE = {"approach_circle": 0.0, "in_circle": 0.0, "circles_held": 0.0}
# who flies the enemy (league.py): stages 3-5 mostly the rule AI, stages 6-8 a full league
SELF_PLAY = {"rule": 0.6, "mirror": 0.15, "champion": 0.1, "past": 0.05, "rival": 0.1}
LEAGUE = {"rule": 0.4, "mirror": 0.25, "champion": 0.1, "past": 0.15, "rival": 0.1}

DEFAULT_CURRICULUM = [
    # ---- single skills, one ship
    # Measured with random play / a simple script (32 battles each): gunnery - target sunk within 150 s
    # 52 % / 76 % (close in, fire at will); capture - circle captured 0 % / 100 % (sail to it); defend -
    # won 12 % / 0 % (sail to the circle). The passive target never scores, so a plain "won" would be
    # passed by random play (the tiebreak goes our way): these stages are judged on their own skill,
    # and their win / loss reward follows it too (env.py) - a slow kill or no capture pays the loss.
    # A battle with a deadline ("within") ends there once it is missed, so it does not run on.
    {"name": "0 Gunnery", "battle": "1 battleship vs a passive cruiser, 7 km, open sea",
     "description": "Destroy a ship: pick the target, keep the guns firing, close in, use torpedoes.",
     "scenario": "scenarios/stage0_gunnery.json", "opponent": "passive",
     "pass_if": "sunk", "within": 150, "promote_win_rate": 0.70, "window": 50, "max_timesteps": 80_000,
     "reward_weights": NO_CIRCLE},
    {"name": "1 Capture", "battle": "1 cruiser, one neutral circle, the enemy far away",
     "description": "Sail into the capture circle and stay inside until it is captured.",
     "scenario": "scenarios/stage1_capture.json", "opponent": "passive",
     "pass_if": "captured", "promote_win_rate": 0.70, "window": 50, "max_timesteps": 100_000},
    {"name": "2 Defend", "battle": "1 cruiser vs 1 cruiser over a neutral circle",
     "description": "Take the circle and hold it while staying afloat: angle, dodge, smoke, repair, fight back.",
     "scenario": "scenarios/stage2_defend.json", "opponent": "rule", "difficulty": 0,
     "pass_if": "won", "promote_win_rate": 0.70, "window": 100, "max_timesteps": 150_000,
     "reward_weights": {"survive": 0.02}},
    # The duel is about gunnery and angling. Its circle lies between the two battleships, so the circle
    # reward pulls the ship bow-on into the enemy's guns: measured, sailing to the circle wins 33% of
    # duels, broadside and fire at will 70%, and MAPPO learned the duel only with the circle terms off.
    {"name": "3 Duel", "battle": "1v1 battleships, 13 km, open sea",
     "description": "Win a battleship duel: choose and time fire, angle the hull, do not throw the ship away.",
     "scenario": "scenarios/stage0_bb_duel.json", "opponent": "league", "opponents": SELF_PLAY, "difficulty": 0,
     "promote_win_rate": 0.70, "window": 100, "max_timesteps": 250_000, "rehearsal": 0.1,
     "reward_weights": NO_CIRCLE},
    # ---- fleets: the commander joins in, and the ships learn to share the reward
    {"name": "4 King of the Hill", "battle": "3v3 mixed fleets, one circle, open sea",
     "description": "The first fleet battle: the commander orders ships to hold the circle or engage.",
     "scenario": "scenarios/stage1_koth_3v3.json", "opponent": "league", "opponents": SELF_PLAY, "difficulty": 1,
     "commander": True, "team_spirit": 0.3, "rehearsal": 0.15, "promote_win_rate": 0.70, "window": 100,
     "max_timesteps": 300_000},
    {"name": "5 Archipelago", "battle": "3v3 mixed fleets, three circles among islands",
     "description": "Which ship holds which circle, and who hunts - with islands, spotting and smoke.",
     "scenario": "scenarios/stage2_archipelago_3v3.json", "opponent": "league", "opponents": SELF_PLAY, "difficulty": 1,
     "commander": True, "team_spirit": 0.5, "rehearsal": 0.15, "promote_win_rate": 0.70, "window": 150,
     "max_timesteps": 350_000},
    # ---- the full game against the Elite AI and a league of our own past selves
    {"name": "6 Domination", "battle": "6v6 on a new random map and weather",
     "description": "The full Domination game against the Elite AI and a league of the fleet's own past selves.",
     "procedural": {"mode": 0, "preset": "random", "density": "random",
                                            "weather": "random", "ships": [6, 6], "time_limit": 900,
                                            "world_reuse": 8},
     "opponent": "league", "opponents": LEAGUE, "difficulty": 2, "commander": True, "team_spirit": 0.8,
     "rehearsal": 0.1, "promote_win_rate": 0.70, "window": 100, "max_timesteps": 500_000},
    {"name": "7 Open", "battle": "4-8 ships a side, random mode, map, weather and circle size",
     "description": "Anything the game can produce: modes, maps, weather and fleet sizes it has not seen.",
     "procedural": {"mode": "random", "preset": "random", "density": "random",
                                      "weather": "random", "ships": [4, 8], "time_limit": 1200,
                                      "capture_radius": [130, 200], "world_reuse": 4},
     "opponent": "league", "opponents": LEAGUE, "difficulty": 2, "commander": True, "team_spirit": 1.0,
     "rehearsal": 0.1, "promote_win_rate": 0.70, "window": 100, "max_timesteps": 570_000},
    # ---- the biggest battle: every class, five circles - the fleet has to split up
    {"name": "8 Archipelago 9v9", "battle": "9v9, every ship class, five circles among islands",
     "description": "Hold more circles than the enemy: three across the middle, one near each fleet. "
                    "Split the fleet - do not crowd the centre.",
     "scenario": "scenarios/stage8_archipelago_9v9.json", "opponent": "league", "opponents": LEAGUE, "difficulty": 2,
     "commander": True, "team_spirit": 1.0, "rehearsal": 0.15,
     "stop_win_rate": 0.70, "stop_window": 120, "eval_battles": 40, "eval_every": 50_000, "max_timesteps": 700_000},
]

RANDOM_CHOICES = {"mode": [0, 1, 2, 3], "preset": [0, 1, 2], "density": [0, 1, 2], "weather": [0, 1, 2, 3]}
MAX_PROCEDURAL_ZONES = 5            # Capture and Control has five circles
HELD_OUT_EVERY = 10                 # map seeds divisible by 10 are kept for held-out evaluation
QUALIFYING = ("rule", "passive")    # battles that count for promotion: never self-play, never evaluations


def load_curriculum(spec) -> list[dict]:
    """"default", a JSON file of stages, or a list of stage dicts."""
    if spec is None or spec == "default":
        return [dict(s) for s in DEFAULT_CURRICULUM]
    if isinstance(spec, str):
        from .env import TRAINING_DIR
        path = spec if os.path.isabs(spec) else os.path.join(TRAINING_DIR, spec)
        with open(path) as f:
            spec = json.load(f)
    return [dict(s) for s in spec]


def stage_sizes(stage: dict, load_scenario) -> tuple[int, int, int]:
    """(most own ships, most enemy ships, most capture circles) a stage can produce."""
    if "procedural" in stage:
        p = stage["procedural"]
        ships = p.get("ships", [6, 6])
        n = int(max(ships)) if isinstance(ships, (list, tuple)) else int(ships)
        modes = RANDOM_CHOICES["mode"] if p.get("mode", 0) == "random" else np.atleast_1d(p.get("mode", 0))
        zones = MAX_PROCEDURAL_ZONES if 3 in list(modes) else 3
        return n, n, zones
    paths = stage["scenario"] if isinstance(stage["scenario"], list) else [stage["scenario"]]
    own = enemy = zones = 0
    for path in paths:
        sc = load_scenario(path)
        own = max(own, sum(1 for s in sc["ships"] if s["team"] == 0))
        enemy = max(enemy, sum(1 for s in sc["ships"] if s["team"] == 1))
        zones = max(zones, len(sc.get("zones", [])))
    return own, enemy, max(1, zones)


# the game's ship classes (Assets/Scripts/Core/NavalTypes.cs, ShipClassType) - in scenario files "cls"
SHIP_CLASSES = {2: ("battleship", "BB"), 1: ("cruiser", "CA"), 0: ("destroyer", "DD"), 3: ("submarine", "SS"),
                4: ("transport", "AP")}


def balanced_fleet(count: int) -> dict[int, int]:
    """The fleet the game builds for a generated battle of `count` ships (FleetSetup.BalancedFor in
    GameManager.cs): about a fifth battleships, submarines from 6 ships up, the rest half cruisers,
    half destroyers. {class: ships}."""
    if count <= 0:
        return {}
    battleships = int(np.clip(round(count * 0.22), 1 if count >= 3 else 0, count))
    subs = int(np.clip(round(count * 0.12), 1, 4)) if count >= 6 else 0
    remaining = max(0, count - battleships - subs)
    cruisers = round(remaining * 0.5)
    fleet = {2: battleships, 1: cruisers, 0: remaining - cruisers, 3: subs}
    while sum(fleet.values()) > count:                      # rounding, as the game does it
        last = next(c for c in (3, 0, 1, 2) if fleet[c] > 0)
        fleet[last] -= 1
    fleet[0] += count - sum(fleet.values())
    return {c: n for c, n in fleet.items() if n}


def fleet_text(fleet: dict[int, int], short: bool = True) -> str:
    """{2: 1, 1: 2} -> "1 BB · 2 CA" (short) or "1 battleship, 2 cruisers"."""
    parts = []
    for c in (2, 1, 0, 3, 4):
        if fleet.get(c):
            name, abbr = SHIP_CLASSES[c]
            parts.append(f"{fleet[c]} {abbr}" if short else f"{fleet[c]} {name}{'s' if fleet[c] > 1 else ''}")
    return (" · " if short else ", ").join(parts) or "-"


def stage_fleets(stage: dict, load_scenario) -> dict:
    """Who sails in a stage: {"ours": {class: ships}, "theirs": {...}, "text": one line for people,
    "short": a shorter one for the game's TRAINING STAGES screen}.
    A generated stage with a range of fleet sizes reports its largest fleet (and the range in "text")."""
    if "procedural" in stage:
        ships = stage["procedural"].get("ships", [6, 6])
        lo, hi = (int(ships[0]), int(ships[-1])) if isinstance(ships, (list, tuple)) else (int(ships), int(ships))
        ours = balanced_fleet(hi)
        text = (f"{fleet_text(ours)} a side" if lo == hi else
                f"{lo}-{hi} ships a side, the game's balanced mix: {lo} = {fleet_text(balanced_fleet(lo))} … "
                f"{hi} = {fleet_text(ours)}")
        short = text if lo == hi else f"{lo}-{hi} a side, balanced mix (up to {fleet_text(ours)})"
        return {"ours": ours, "theirs": dict(ours), "text": text, "short": short}
    paths = stage["scenario"] if isinstance(stage["scenario"], list) else [stage["scenario"]]
    sc = load_scenario(paths[0])
    count = lambda team: {c: n for c in SHIP_CLASSES if (n := sum(1 for s in sc["ships"] if s["team"] == team
                                                                   and int(s["cls"]) == c))}
    ours, theirs = count(0), count(1)
    passive = " (a passive target)" if stage.get("opponent") == "passive" else ""
    text = (f"{fleet_text(ours)} a side" if ours == theirs and not passive else
            f"ours: {fleet_text(ours)} · enemy: {fleet_text(theirs)}{passive}")
    return {"ours": ours, "theirs": theirs, "text": text, "short": text}


def map_seed(rng: np.random.Generator, held_out: bool) -> int:
    """Training maps and held-out maps never share a seed."""
    if held_out:
        return HELD_OUT_EVERY * int(rng.integers(1, 99_999))
    while True:
        seed = int(rng.integers(1, 999_999))
        if seed % HELD_OUT_EVERY:
            return seed


def procedural_reset(p: dict, rng: np.random.Generator, world: tuple[int, int],
                     held_out: bool = False) -> tuple[dict, tuple[int, int]]:
    """The reset message for a generated battle, and the (map seed, battles fought on it) to keep.
    Held-out battles always get a fresh held-out map."""
    def pick(key, default):
        v = p.get(key, default)
        if v == "random":
            return int(rng.choice(RANDOM_CHOICES[key]))
        if isinstance(v, (list, tuple)):
            return int(rng.choice(v))
        return int(v)

    seed, used = world
    if held_out or used >= int(p.get("world_reuse", 1)) or seed % HELD_OUT_EVERY == 0:
        seed, used = map_seed(rng, held_out), 0
    ships = p.get("ships", [6, 6])
    lo, hi = (ships[0], ships[-1]) if isinstance(ships, (list, tuple)) else (ships, ships)
    n = int(rng.integers(int(lo), int(hi) + 1))
    msg = {"use_scenario": False, "mode": pick("mode", 0), "preset": pick("preset", 0), "density": pick("density", 1),
           "weather": pick("weather", 0), "player_ships": n, "enemy_ships": n, "seed": seed,
           "time_limit": float(p.get("time_limit", 0))}
    if "capture_radius" in p:
        r = p["capture_radius"]
        msg["capture_radius"] = float(rng.uniform(r[0], r[1])) if isinstance(r, (list, tuple)) else float(r)
    return msg, (seed, used + 1)


class CurriculumCallback(BaseCallback):
    """Promotes the environment to the next stage, and applies the final stage's stopping rule.

    Promotion counts only battles that started on the current stage against the stage's own
    opponent (the rule-based AI, or the passive target of the first stages; never self-play), and
    the window starts empty on every new stage, so a promotion is always earned on the stage itself.

    The windows carry over between sessions: at the start of training they are rebuilt from the
    run's monitor.csv, so a session that stops after 60 of the 100 battles a stage needs is continued
    by the next session (yours or a teammate's) instead of starting the count again.

    stop_on_promotion=True ends training right after a promotion (the per-stage notebooks use it: the
    saved model then carries the new stage, and the next stage's notebook continues from it).

    fresh=True trains the stage AGAIN (FORCE_STAGE in the stage notebooks): this session starts with
    an empty promotion window and counts the stage's max_timesteps from now. Without it, a run brought
    back to a stage it passed - or left at its cap - would pass or hit the cap again on its first step,
    since both are rebuilt from the battle log.
    """

    def __init__(self, verbose: int = 1, stop_on_promotion: bool = False, fresh: bool = False):
        super().__init__(verbose)
        self.stop_on_promotion = stop_on_promotion
        self.fresh = fresh
        self.results: list[float] = []          # current stage, rule-AI battles
        self.held_out: list[float] = []         # final stage, held-out evaluation battles
        self.last_eval = 0
        self.history: list[dict] = []           # promotions and evaluations, for the notebook
        self.promoted = False
        self.finished = False                   # the final stage's stopping rule is met

    def _on_training_start(self) -> None:
        self.last_eval = self.num_timesteps
        self.promoted = self.finished = self.moved_on_unpassed = self.capped_out = False
        env = self.model.env
        stage = env.stages[env.stage]
        if self.fresh:                         # the window and the cap count from here on, also next session
            self._record("again", stage, env.stage)
        self.results, self.held_out = ([], []) if self.fresh else self._from_log()
        # where the timesteps on this stage started counting: earlier sessions' battles on it come first
        self._stage_from = self.num_timesteps - (0 if self.fresh else self._steps_on_stage())
        if self.fresh and self.verbose:
            print(f"training '{stage['name']}' again: a fresh promotion window"
                  + (f" and {int(stage['max_timesteps']):,} timesteps before its cap" if stage.get("max_timesteps") else ""))
        cap = stage.get("max_timesteps")
        if cap and self.verbose:
            print(f"'{stage['name']}': {self.num_timesteps - self._stage_from:,} of at most {int(cap):,} timesteps on it so far")
        if self.results and self.verbose:
            window = int(stage.get("window", 100))
            print(f"continuing the promotion window of '{stage['name']}': {len(self.results)} of {window} battles so far, "
                  f"won {np.mean(self.results):.0%} (needs {stage.get('promote_win_rate', 0):.0%})")
        if self.held_out and self.verbose:
            need = int(stage.get("stop_window", 250))
            print(f"continuing the held-out window: {len(self.held_out)} of {need} battles, won {np.mean(self.held_out):.0%}"
                  + (" - the stopping rule is already met; training on tries to do better"
                     if len(self.held_out) >= need and np.mean(self.held_out) >= stage.get("stop_win_rate", 1.0) else ""))

    COLUMNS = ["timesteps", "stage", "name", "event", "pass_rate", "battles", "log_rows"]

    def _record(self, event: str, stage: dict, k: int) -> None:
        """One line in logs/curriculum.csv (next to monitor.csv) each time the run leaves a stage - read
        by compare_stages, and shared with the team like the other logs - and an "again" line when a
        session starts training a stage again (fresh), from which its window and cap count."""
        path = getattr(self.model.env, "path", None)
        if not path:
            return
        out = os.path.join(os.path.dirname(path), "curriculum.csv")
        if os.path.exists(out):
            with open(out) as f:
                lines = f.read().splitlines()
            if lines and lines[0] != ",".join(self.COLUMNS):     # an older layout: add the new column
                with open(out, "w") as f:
                    f.write("\n".join([",".join(self.COLUMNS)] + [line + "," for line in lines[1:]]) + "\n")
        new = not os.path.exists(out)
        with open(out, "a", newline="") as f:
            w = csv.writer(f)
            if new:
                w.writerow(self.COLUMNS)
            w.writerow([self.num_timesteps, k, stage["name"], event,
                        round(float(np.mean(self.results)), 3) if self.results else "", len(self.results),
                        len(self._log_rows(all_rows=True))])

    def _log_rows(self, all_rows: bool = False) -> list[dict]:
        """monitor.csv's rows of the current stage since the run last started training it again (the
        latest "again" line in curriculum.csv) - or, all_rows, every row."""
        env = self.model.env
        path = getattr(env, "path", None)                  # the Monitor wrapper's file
        if not path or not os.path.exists(path):
            return []
        with open(path) as f:
            next(f)                                        # the '#{...}' header line
            rows = list(csv.DictReader(f))
        if all_rows:
            return rows
        since, marks = 0, os.path.join(os.path.dirname(path), "curriculum.csv")
        if os.path.exists(marks):
            with open(marks) as f:
                for m in csv.DictReader(f):
                    if m.get("event") == "again" and int(m["stage"]) == env.stage:
                        since = int(m.get("log_rows") or 0)
        return [r for r in rows[since:] if int(float(r.get("stage") or 0)) == env.stage]

    def _steps_on_stage(self) -> int:
        """The timesteps this run already spent on its current stage (training battles in monitor.csv)."""
        return int(sum(float(r.get("l") or 0) for r in self._log_rows()
                       if not str(r.get("opponent", "")).startswith("eval")))

    def _from_log(self) -> tuple[list[float], list[float]]:
        """The current stage's rule-AI battles and held-out battles, from the run's monitor.csv."""
        env = self.model.env
        stage = env.stages[env.stage]
        rows = self._log_rows()
        passed = "passed" if rows and rows[0].get("passed") not in (None, "") else "won"
        results = [float(r[passed]) for r in rows if r.get("opponent", "rule") in QUALIFYING]
        held_out = [float(r[passed]) for r in rows if r.get("opponent") == "eval-heldout"]
        return results[-int(stage.get("window", 100)):], held_out[-int(stage.get("stop_window", 250)):]

    def _on_step(self) -> bool:
        env = self.model.env
        stage = env.stages[env.stage]
        for info in self.locals.get("infos", []):
            if info and info.get("stage") == env.stage and info.get("opponent") in QUALIFYING and not info.get("evaluation"):
                self.results.append(float(info.get("passed", info["won"])))
        window = int(stage.get("window", 100))
        self.results = self.results[-window:]
        threshold = stage.get("promote_win_rate")
        last = env.stage == len(env.stages) - 1
        if not last and threshold is not None and len(self.results) >= window and np.mean(self.results) >= threshold:
            msg = (f"stage '{stage['name']}' passed: passed {np.mean(self.results):.0%} of the last {window} "
                   f"qualifying battles - moving on to '{env.stages[env.stage + 1]['name']}'")
            self.history.append({"timesteps": self.num_timesteps, "event": msg})
            if self.verbose:
                print(f"*** {msg} (at {self.num_timesteps} timesteps) ***")
            self._record("passed", stage, env.stage)
            env.set_stage(env.stage + 1)
            self.results = []
            self.promoted = True
            self._stage_from = self.num_timesteps
            if self.stop_on_promotion:
                return False
            return True
        cap = stage.get("max_timesteps")
        if not last and cap and self.num_timesteps - self._stage_from >= int(cap):
            rate = f"passed {np.mean(self.results):.0%} of the last {len(self.results)}" if self.results else "no battles yet"
            msg = (f"stage '{stage['name']}' NOT passed in {int(cap):,} timesteps (its max_timesteps; {rate}, "
                   f"needs {threshold or 0:.0%}) - moving on to '{env.stages[env.stage + 1]['name']}'")
            self.history.append({"timesteps": self.num_timesteps, "event": msg})
            if self.verbose:
                print(f"*** {msg} (at {self.num_timesteps} timesteps) ***")
            self._record("not passed", stage, env.stage)
            env.set_stage(env.stage + 1)
            self.results = []
            self.promoted = self.moved_on_unpassed = True
            self._stage_from = self.num_timesteps
            if self.stop_on_promotion:
                return False
        elif last and cap and self.num_timesteps - self._stage_from >= int(cap):
            # the final stage has nothing to move on to: its cap ends the training
            msg = (f"final stage '{stage['name']}': its stopping rule was not met in {int(cap):,} timesteps (its "
                   f"max_timesteps) - training is over")
            self.history.append({"timesteps": self.num_timesteps, "event": msg})
            if self.verbose:
                print(f"*** {msg} (at {self.num_timesteps} timesteps) ***")
            self._record("not passed", stage, env.stage)
            self.finished = self.capped_out = True
            return False
        return True

    def _on_rollout_end(self) -> bool:
        """Between updates: on the final stage, play held-out battles and check the stopping rule."""
        env = self.model.env
        stage = env.stages[env.stage]
        if env.stage != len(env.stages) - 1 or stage.get("stop_win_rate") is None:
            return True
        if self.num_timesteps - self.last_eval < int(stage.get("eval_every", 100_000)):
            return True
        from .utils import evaluate
        self.last_eval = self.num_timesteps
        # held_out: generated maps from seeds training never uses (a scenario stage keeps its own map);
        # the battles are logged as "eval-heldout", apart from other evaluations such as the baselines
        r = evaluate(self.model, env, n_battles=int(stage.get("eval_battles", 50)), held_out=True, keep_results=True)
        self.held_out += [float(x.get("passed", x["won"])) for x in r["results"]]
        need = int(stage.get("stop_window", 250))
        self.held_out = self.held_out[-need:]
        rate = float(np.mean(self.held_out))
        msg = (f"evaluation for the stopping rule: won {r['win_rate']:.0%} of {r['battles']} battles; "
               f"{rate:.0%} over the last {len(self.held_out)}/{need}")
        self.history.append({"timesteps": self.num_timesteps, "event": msg})
        if self.verbose:
            print(f"*** {msg} ***")
        self.model.reset_battles()                  # the evaluation interrupted the training battles
        if len(self.held_out) >= need and rate >= stage["stop_win_rate"]:
            if self.verbose:
                print(f"*** stopping rule met: {rate:.0%} >= {stage['stop_win_rate']:.0%} over {need} evaluation battles ***")
            self._record("passed", stage, env.stage)
            self.finished = True
            return False
        return True
